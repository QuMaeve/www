<div id="act_tab" ><script>view("act");</script>
<form   method="get">
<h1 align="center">Act</h1>
<input  type="button" height="50" align="center" name="cr_act" value="&#1057;&#1086;&#1079;&#1076;&#1072;&#1090;&#1100; &#1085;&#1086;&#1074;&#1099;&#1081; &#1072;&#1082;&#1090;" onclick="f_act_create()"  />
</form>
<div id="tab_act_view"></div>
</div>
<div id="add_act_div"  style="display:none">
  <? include("create_act.php"); ?>
</div>
