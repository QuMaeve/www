<div id="filtr_div_obr" style="display:none">
  <label>&#1060;&#1080;&#1083;&#1100;&#1090;&#1088; &#1087;&#1086; &#1074;&#1093;&#1086;&#1076;&#1103;&#1097;&#1080;&#1084; <br />
  &#8470; &#1074;&#1093;&#1086;&#1076;&#1103;&#1097;&#1077;&#1075;&#1086;
    <input type="text" name="incoming_doc" onkeyup="" /></label>

 &#1044;&#1080;&#1072;&#1087;&#1072;&#1079;&#1086;&#1085; &#1076;&#1072;&#1090;: 
 <label>&#1089;<input type="date" name="incoming_doc_date_begin" onkeyup="" /></label>
 <label> &#1087;&#1086;<input type="date" name="incoming_doc_date_end" onkeyup="" /></label>
 <hr size="2px" align="center">
 
   <label>&#1060;&#1080;&#1083;&#1100;&#1090;&#1088; &#1087;&#1086; &#1086;&#1073;&#1098;&#1077;&#1082;&#1090;&#1091;  (&#1059;&#1050;, &#1058;&#1057;&#1046; &#1080; &#1090;&#1076;) <br />
  
  <input type="text" name="incoming_doc" onkeyup="" /></label>
   <hr size="2px" align="center">
      <label>&#1060;&#1080;&#1083;&#1100;&#1090;&#1088; &#1087;&#1086; &#1072;&#1076;&#1088;&#1077;&#1089;&#1091; <br />
  
  <input type="text" name="incoming_doc" onkeyup="" /></label>
   <hr size="2px" align="center">
      <label>&#1060;&#1080;&#1083;&#1100;&#1090;&#1088; &#1087;&#1086; &#1085;&#1072;&#1088;&#1091;&#1096;&#1077;&#1085;&#1080;&#1102; <br />
  
  <input type="text" name="incoming_doc" onkeyup="" /></label>
   <hr size="2px" align="center">
      <label>&#1060;&#1080;&#1083;&#1100;&#1090;&#1088; &#1087;&#1086; &#1090;&#1077;&#1082;&#1089;&#1090;&#1091; &#1087;&#1088;&#1080;&#1084;&#1077;&#1095;&#1072;&#1085;&#1080;&#1102; <br />
  
  <input type="text" name="incoming_doc" onkeyup="" /></label>
   <hr size="2px" align="center">
</div>
